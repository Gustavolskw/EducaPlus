package Educa.plus.Educa;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EducaPLusApplicationTests {

	@Test
	void contextLoads() {
	}

}
